import { NextRequest } from "next/server";
import { buildAnalysisPrompt, createAnalysisStream } from "@/lib/claude";
import { AnalysisMode, MarketKey } from "@/lib/types";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { market, mode, priceData, newsData } = body as {
    market: MarketKey;
    mode: AnalysisMode;
    priceData?: string;
    newsData?: string;
  };

  const { prompt, system } = buildAnalysisPrompt(market, mode, priceData, newsData);
  const useSearch = mode === "geopolitical" || !priceData;

  const stream = await createAnalysisStream(prompt, system, useSearch);

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
