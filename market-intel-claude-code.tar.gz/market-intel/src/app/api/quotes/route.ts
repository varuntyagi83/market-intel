import { NextRequest, NextResponse } from "next/server";
import { getMultipleQuotes } from "@/lib/finnhub";
import { getCryptoPrices } from "@/lib/coingecko";
import { MARKETS } from "@/lib/markets";
import { MarketKey } from "@/lib/types";

export async function GET(req: NextRequest) {
  const market = req.nextUrl.searchParams.get("market") as MarketKey;

  if (!market || !MARKETS[market]) {
    return NextResponse.json({ error: "Invalid market" }, { status: 400 });
  }

  try {
    if (market === "CRYPTO") {
      const data = await getCryptoPrices(MARKETS.CRYPTO.tickers);
      return NextResponse.json({ type: "crypto", data });
    } else {
      const allTickers = [...MARKETS[market].indices, ...MARKETS[market].tickers];
      const data = await getMultipleQuotes(allTickers);
      return NextResponse.json({ type: "stock", data });
    }
  } catch (err) {
    return NextResponse.json(
      { error: `Failed to fetch quotes: ${err}` },
      { status: 500 }
    );
  }
}
