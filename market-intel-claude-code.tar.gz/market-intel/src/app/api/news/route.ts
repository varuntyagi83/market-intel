import { NextRequest, NextResponse } from "next/server";
import { getMarketNews } from "@/lib/finnhub";
import { MARKETS } from "@/lib/markets";
import { MarketKey } from "@/lib/types";

export async function GET(req: NextRequest) {
  const market = req.nextUrl.searchParams.get("market") as MarketKey;

  if (!market || !MARKETS[market]) {
    return NextResponse.json({ error: "Invalid market" }, { status: 400 });
  }

  try {
    const news = await getMarketNews(MARKETS[market].finnhubCategory);
    return NextResponse.json(news);
  } catch (err) {
    return NextResponse.json(
      { error: `Failed to fetch news: ${err}` },
      { status: 500 }
    );
  }
}
