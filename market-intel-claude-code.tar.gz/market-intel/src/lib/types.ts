// ═══════════════════════════════════════════════════════════
// Market Intelligence Agent — Type Definitions
// ═══════════════════════════════════════════════════════════

export type MarketKey = "US" | "EU" | "INDIA" | "CRYPTO";

export interface MarketDef {
  label: string;
  icon: string;
  tickers: string[];
  indices: string[];
  finnhubCategory: string; // for news API
}

export interface StockQuote {
  symbol: string;
  name?: string;
  price: number;
  change: number;
  changePct: number;
  high: number;
  low: number;
  open: number;
  prevClose: number;
  marketCap?: string;
  volume?: number;
}

export interface CryptoPrice {
  id: string;
  symbol: string;
  name: string;
  current_price: number;
  market_cap: number;
  price_change_percentage_24h: number;
  high_24h: number;
  low_24h: number;
  total_volume: number;
  image: string;
}

export interface NewsItem {
  id: number;
  headline: string;
  summary: string;
  source: string;
  url: string;
  image: string;
  datetime: number; // unix timestamp
  category: string;
  related: string; // comma-separated tickers
}

export type AnalysisMode = "full" | "technical" | "geopolitical" | "sentiment";

export interface AnalysisRequest {
  market: MarketKey;
  mode: AnalysisMode;
  priceData?: string; // serialized price context
  newsData?: string;  // serialized news context
}

export interface DeepDiveRequest {
  symbol: string;
  priceData?: string;
}
